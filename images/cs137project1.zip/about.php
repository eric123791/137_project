<!-- about.php -->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
 "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <title>TicketzHub - About Us</title>
  <meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
  <link rel="stylesheet" type="text/css" href="css/default.css" />
  <script type="text/javascript" src="js/message.js"></script>
</head>
<body onload = "startRotation();scrollingMsg()">
  <div id = "page">
    <?php
     include("common/welcome.php");
     include("common/mainmenu.php");
    ?>

    <div id="content">
      <div id="text">
        <h3>About TicketzHub</h3>
        <p>Founded in 2015, TicketzHub was created as to serve those who
          want to buy and sell (coming soon!) any kind of sports tickets. Offering not only the
          average quality seats in the house but also the highest quality also.
          TicketzHub takes great pride in helping people to have fun.
          lives.</p>
          <p>We offer an online servies that people can buy and sell tickets.
            We ensure the best quality of services possible to every customer.
            Each transaction is secure and ensure by our policy.</p>
            <p>TicketzHub regularly conducts independent product quality
              assurance testing to guarantee their clients are receiving the right
              tickets. We are proud to be part of the organizations like NBA, MLB
              and NFL. These organizations and others like them allow TicketzHub to
              provide the best quality of tickets there is to our customers.
              TicketzHub maintains ties with the university across USA</p>
            </div>
            <?php
             include("common/rotate.php");
            ?>
            <?php
             include("common/footer.php");
            ?>
          </div>

        </div>
      </body>
      </html>
