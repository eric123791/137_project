<?php
include("common/logo.php");
?>
<div id="welcome">
  <h3>Welcome!</h3>
  <form name="msgForm">
    <input type="text" name="scrollingMsgBox" size="30">
  </form>
</div>
