<div id = "footer">
  <p id = "footerName">
    TicketzHub &copy; 2015 Hua Hsin and Edmond Ye
  </p>
  <ul id="footerLinks">
    <li><a href="contact.php">Contact Us</a></li>
    <li><a href="sitemap.php">Site Map</a></li>
  </ul>
</div>
