<div id = "logo">
  <img src= "images/logo.png" alt = "logo" width="450px" height="175px" />
</div>
