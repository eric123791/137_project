<script type="text/javascript" src="js/rotate.js"></script>
<div id="image">
  <img id="placeholder" src="" alt="tickets" width="280px" height="160px" />
</div>
